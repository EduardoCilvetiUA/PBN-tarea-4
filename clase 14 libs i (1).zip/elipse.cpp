#include"elipse.h"

double elipse::area() {
    return rectangulo::area()*0.785398;
}